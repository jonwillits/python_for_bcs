import random
from src import experiment
from src import display


def main():
    condition_config_file = random.choice(["config/condition1.csv", "config/condition2.csv"])
    the_experiment = experiment.Experiment(condition_config_file)
    the_display = display.Display(the_experiment)
    the_display.root.mainloop()


if __name__ == '__main__':
    main()