import csv
import os
import random


class Experiment:

    def __init__(self, condition_file):
        self.condition_file = condition_file
        print(self.condition_file)

        self.config_dict = None
        self.condition = None
        self.instruction_list = None
        self.test_list = None
        self.familiarization_list = None

        self.load_config_info()
        print(self.config_dict)
        self.create_instructions()
        print(self.instruction_list)
        self.create_stimuli_lists()
        print(self.familiarization_list)
        print(self.test_list)
        self.init_results()

    @staticmethod
    def convert_value(input_value):
        try:
            value = int(input_value)
        except ValueError:
            try:
                value = float(input_value)
            except ValueError:
                value = input_value
        return value

    def load_config_dict(self, filename):
        with open(filename, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                try:
                    key = row[0]
                    value = row[1]
                except IndexError:
                    pass
                self.config_dict[key] = self.convert_value(value)

    def load_config_info(self):
        self.config_dict = {}
        self.load_config_dict('config/config.csv')
        self.load_config_dict(self.condition_file)
        self.condition = self.condition_file[7:-4]

    def create_instructions(self):
        self.instruction_list = []
        with open(self.config_dict['instruction_file'], 'r') as file:
            for line in file:
                line = line.strip('\n')
                instruction_sentences = line.split('.')
                instruction_string = ".\n".join(instruction_sentences)
                self.instruction_list.append(instruction_string)

    def create_test_list(self, full_stimulus_list):
        num_old_test_trials = self.config_dict['num_test_trials']//2
        start = self.config_dict['num_familiarization_trials']
        stop = self.config_dict['num_familiarization_trials'] + num_old_test_trials
        self.test_list = self.familiarization_list[:num_old_test_trials]
        self.test_list += full_stimulus_list[start:stop]
        random.shuffle(self.test_list)

    def create_stimuli_lists(self):
        full_stimulus_list = os.listdir('stimuli/images/')
        for thing in full_stimulus_list[:]:
            if thing.startswith("."):
                full_stimulus_list.remove(thing)
        random.shuffle(full_stimulus_list)
        self.familiarization_list = full_stimulus_list[:self.config_dict['num_familiarization_trials']]

        self.create_test_list(full_stimulus_list)

        for i in range(len(self.familiarization_list)):
            self.familiarization_list[i] = self.familiarization_list[i][:-4]
        for i in range(len(self.test_list)):
            self.test_list[i] = self.test_list[i][:-4]
        random.shuffle(self.familiarization_list)

    def init_results(self):
        pass
