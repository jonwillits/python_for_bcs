import tkinter as tk
from PIL import Image, ImageTk
# if you get an error on line 2, do pip3 install pillow


class Display:

    def __init__(self, experiment):
        self.experiment = experiment

        self.root = None
        self.main_frame = None
        self.stimulus_label = None
        self.instructions_text_label = None
        self.key_flag = None
        self.tk_image_dict = None
        self.test_trial_number = None

        self.init_display()
        self.run_experiment()

    def init_display(self):
        self.root = tk.Tk()
        self.root.geometry("{}x{}".format(self.experiment.config_dict['window_width'], self.experiment.config_dict['window_height']))
        self.root.title("Experiment")
        self.root.configure(bg="white")
        self.root.resizable(False, False)
        self.main_frame = tk.Frame(self.root, bg="white",
                                   height=self.experiment.config_dict['window_height'],
                                   width=self.experiment.config_dict['window_width'])
        self.main_frame.pack()

        self.instructions_text_label = tk.Label(self.main_frame, anchor='center',
                                                height=self.experiment.config_dict['window_height'],
                                                width=self.experiment.config_dict['window_width'],
                                                bg=self.experiment.config_dict['bg_color'],
                                                fg=self.experiment.config_dict['font_color'],
                                                font="{} {}".format(self.experiment.config_dict['instructions_font'],
                                                                    self.experiment.config_dict['instructions_font_size']))

        self.stimulus_label = tk.Label(self.main_frame, anchor='center',
                                       height=self.experiment.config_dict['window_height'],
                                       width=self.experiment.config_dict['window_width'],
                                       bg=self.experiment.config_dict['bg_color'],
                                       font="{} {}".format(self.experiment.config_dict['stimulus_font'],
                                                           self.experiment.config_dict['stimulus_font_size']),
                                       fg=self.experiment.config_dict['font_color'])

        if self.experiment.config_dict['stimulus_type'] == "images":
            self.preload_images()

    def load_image(self, image_name):
        image = Image.open("stimuli/images/" + image_name + ".jpg")
        photo_image = ImageTk.PhotoImage(image)
        self.tk_image_dict[image_name] = photo_image

    def preload_images(self):
        self.tk_image_dict = {}
        for image_name in self.experiment.test_list:
            self.load_image(image_name)
        for image_name in self.experiment.familiarization_list:
            self.load_image(image_name)

    def run_experiment(self):
        self.test_trial_number = 0
        self.show_instructions(self.experiment.instruction_list[0], True)
        self.run_familiarization_condition()
        self.show_instructions(self.experiment.instruction_list[1], False, self.experiment.config_dict['test_delay'])
        self.show_instructions(self.experiment.instruction_list[2], False)
        self.show_instructions(self.experiment.instruction_list[3], False)
        self.show_instructions(self.experiment.instruction_list[4], False)
        self.run_test_condition()
        self.experiment.save_data(data)
        self.show_instructions(self.experiment.instruction_list[5], True)
        self.root.destroy()

    def key_pressed(self, event, valid_keys):
        if event.keysym in valid_keys:
            self.key_flag[0] = True  # set flag to true
            self.root.unbind('<Key>')
            self.root.focus_set()

    def show_instructions(self, instructions, end_on_key_press, extra_delay=None):
        self.instructions_text_label.configure(text=instructions)
        self.instructions_text_label.pack()
        self.instructions_text_label.pack_propagate(False)
        self.root.update()

        if end_on_key_press:
            self.key_flag = [False]  # list to hold flag value
            self.root.bind('<Key>', lambda event: self.key_pressed(event, ["space"]))
            while not self.key_flag[0]:  # loop until flag is true
                self.root.update()
        else:
            self.root.after(self.experiment.config_dict['instruction_delay'])

        if extra_delay is not None:
            self.root.after(extra_delay)
        self.instructions_text_label.pack_forget()

    def inter_trial_interval(self):
        if self.experiment.config_dict['stimulus_type'] == 'text':
            self.stimulus_label.configure(text="")
        elif self.experiment.config_dict['stimulus_type'] == 'images':
            self.stimulus_label.configure(image=None)
            self.stimulus_label.image = None
        self.root.update()

        self.root.after(self.experiment.config_dict['inter_trial_interval'])

    def present_stimulus(self, stimulus_name):
        if self.experiment.config_dict['stimulus_type'] == 'text':
            self.stimulus_label.configure(text=stimulus_name)
        elif self.experiment.config_dict['stimulus_type'] == 'images':
            stimulus_image = self.tk_image_dict[stimulus_name]
            self.stimulus_label.configure(image=stimulus_image)
            self.stimulus_label.image = stimulus_image
        self.root.update()

    def present_test_trial(self, stimulus_name):
        self.present_stimulus(stimulus_name)
        self.key_flag = [False]  # list to hold flag value
        self.root.bind('<Key>', lambda event: self.key_pressed(event, ["j", "k"]))
        while not self.key_flag[0]:  # loop until flag is true
            self.root.update()
        self.inter_trial_interval()

    def run_test_condition(self):
        self.stimulus_label.pack()
        for i in range(self.experiment.config_dict['num_test_trials']):
            self.test_trial_number += 1
            self.present_test_trial(self.experiment.test_list[i])
        self.stimulus_label.pack_forget()

    def present_familiarization_trial(self, stimulus_name):
        self.present_stimulus(stimulus_name)
        self.root.after(self.experiment.config_dict['stimulus_presentation_time'])
        self.inter_trial_interval()

    def run_familiarization_condition(self):
        self.stimulus_label.pack()
        for i in range(self.experiment.config_dict['num_familiarization_trials']):
            self.present_familiarization_trial(self.experiment.familiarization_list[i])
        self.stimulus_label.pack_forget()


